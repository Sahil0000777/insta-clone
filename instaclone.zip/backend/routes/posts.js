const express = require('express');
const router = express.Router();
const Post = require('../models/Post');

router.get('/', async (req, res) => {
  const posts = await Post.find().sort({ _id: -1 });
  res.json(posts);
});

router.post('/', async (req, res) => {
  const { username, imageUrl, caption } = req.body;
  const newPost = new Post({ username, imageUrl, caption });
  await newPost.save();
  res.json(newPost);
});

router.post('/:id/like', async (req, res) => {
  const post = await Post.findById(req.params.id);
  post.likes += 1;
  await post.save();
  res.json(post);
});

module.exports = router;
